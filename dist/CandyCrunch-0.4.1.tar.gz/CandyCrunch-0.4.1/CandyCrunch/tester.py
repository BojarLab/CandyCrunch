from prediction import wrap_inference
wrap_inference()
